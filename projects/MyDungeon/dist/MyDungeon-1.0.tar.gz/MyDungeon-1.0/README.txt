=========
MyDungeon
========

MyDungeon is just a silly portion of a game I
wrote while learning to program in Python.
This is just a package I am creating in order
to learn how to create a package. I am using
The Hitchhiker's Guide to Packaging 1.0
http://guide.python-distribute.org/creation.html
